set(0, 'DefaultAxesFontName', 'Times New Roman'); 
set(0, 'DefaultAxesFontSize', 14); 
set(0, 'DefaultTextFontName', 'Times New Roman'); 
set(0, 'DefaultTextFontSize', 14);
% ---- Load Data ----
load('ECG_database.mat'); % Load ECG data
fs = 1000;                % Sampling frequency
d1 = Org_Data1(2, :) / 200;  % Original ECG signal (clean signal)
noise_wn = wn / 10;          % Added white noise
noise_pli = 0.1 * sin(2 * pi * 60 * (0:length(d1) - 1) / fs); % Power line interference noise
x1 = d1 + noise_wn;          % Noisy signal (ECG + white noise)

% ---- Initialize Parameters ----
lamda = 1;   % RLS parameter
mu = 0.02;   % LMS step size
a = 0.1;     % NLMS step size
mu2 = 0.02;  % NLMS step size
M1 = 2;      % LMS filter order
M2 = 2;      % NLMS filter order
M3 = 2;      % RLS filter order

% ---- Apply LMS, NLMS, and RLS filters ----
[e1_wn, y1_wn, w1_wn] = myLMS(x1, noise_wn, mu, M1);          % LMS filtering
[e2_wn, y2_wn, w2_wn] = myNLMS(x1, noise_wn, mu2, M2, a);    % NLMS filtering
[e3_wn, y3_wn, w3_wn] = myRLS(x1, noise_wn, lamda, M3);      % RLS filtering

% ---- Ensure consistent dimensions ----
d1 = d1(:); % Convert to column vector
e1_wn = e1_wn(:); 
e2_wn = e2_wn(:); 
e3_wn = e3_wn(:);

% ---- SNR Calculation ----
% SNR of the original signal
snr_original = calculate_snr(d1, noise_wn(:));  

% SNR after LMS, NLMS, and RLS filtering
snr_lms = calculate_snr(d1, d1 - e1_wn);   % LMS noise is d1 - e1_wn
snr_nlms = calculate_snr(d1, d1 - e2_wn); % NLMS noise is d1 - e2_wn
snr_rls = calculate_snr(d1, d1 - e3_wn);  % RLS noise is d1 - e3_wn

% ---- MSE and RMSE Calculation ----
mse_lms = mean((d1 - e1_wn).^2);
rmse_lms = sqrt(mse_lms);

mse_nlms = mean((d1 - e2_wn).^2);
rmse_nlms = sqrt(mse_nlms);

mse_rls = mean((d1 - e3_wn).^2);
rmse_rls = sqrt(mse_rls);

% ---- PRD Calculation ----
prd_lms = (norm(d1 - e1_wn) / norm(d1)) * 100;
prd_nlms = (norm(d1 - e2_wn) / norm(d1)) * 100;
prd_rls = (norm(d1 - e3_wn) / norm(d1)) * 100;

% ---- Display Results ----
fprintf('Original SNR (with noise): %.2f dB\n', snr_original);
fprintf('LMS Filter SNR: %.2f dB, MSE: %.6f, RMSE: %.6f, PRD: %.2f%%\n', snr_lms, mse_lms, rmse_lms, prd_lms);
fprintf('NLMS Filter SNR: %.2f dB, MSE: %.6f, RMSE: %.6f, PRD: %.2f%%\n', snr_nlms, mse_nlms, rmse_nlms, prd_nlms);
fprintf('RLS Filter SNR: %.2f dB, MSE: %.6f, RMSE: %.6f, PRD: %.2f%%\n', snr_rls, mse_rls, rmse_rls, prd_rls);

% ---- Plotting ----
figure;
plot(x1); 
title('ECG corrupted by White Gaussian Noise');
xlabel('Samples (n)');
ylabel('Amplitude (mV)');
grid on;

figure;
plot(e1_wn); 
title('LMS Filter Response');
xlabel('Samples (n)');
ylabel('Amplitude (mV)');
grid on;

figure;
plot(e2_wn); 
title('NLMS Filter Response');
xlabel('Samples (n)');
ylabel('Amplitude (mV)');
grid on;

figure;
plot(e3_wn); 
title('RLS Filter Response');
xlabel('Samples (n)');
ylabel('Amplitude (mV)');
grid on;

figure;
plot(d1); 
title('Clean ECG Signal');
xlabel('Samples (n)');
ylabel('Amplitude (mV)');
grid on;

figure;
plot(y1_wn' - noise_wn, 'r'); hold on;
plot(y2_wn' - noise_wn, 'b'); hold on;
plot(y3_wn' - noise_wn, 'g'); 
title('Error Convergence Curve of Three Algorithms for WN');
xlabel('Samples (n)');
ylabel('Error Magnitude');
legend('LMS', 'NLMS', 'RLS');
grid on;

% ---- SNR Calculation Function ----
function snr_value = calculate_snr(clean_signal, noise_signal)
    % Ensure signal lengths match
    assert(length(clean_signal) == length(noise_signal), 'Signal and noise length mismatch');
    
    % Convert to column vectors
    clean_signal = clean_signal(:);
    noise_signal = noise_signal(:);
    
    % Compute signal power (mean square)
    signal_power = mean(clean_signal.^2);
    
    % Compute noise power (mean square)
    noise_power = mean(noise_signal.^2);
    
    % Compute SNR (dB)
    snr_value = 10 * log10(signal_power / noise_power);
end
