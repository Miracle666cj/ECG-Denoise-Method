clear, clc;

%% 1. Load ECG Data
load('ECG_database.mat');  % Load ECG data
signal = Data3(1:1800);  % Extract first 1800 samples of ECG signal
Fs = FS;  % Sampling frequency from the data

%% 1. Plot Clean ECG Signal
figure(2);
subplot(3,1,1);
plot(signal);
title('Clean ECG Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the clean ECG signal
XK1 = fft(signal, 1800);
magXK1 = abs(XK1);  % Magnitude spectrum
figure(3);
subplot(3,1,1);
k1 = 0:length(magXK1)-1;
stem(k1, magXK1, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('Clean ECG Signal Spectrum');

%% 2. Add Baseline Drift to the Signal
n1 = length(signal) / 3;
x1 = zeros(1, n1);
t = 1:length(signal) - n1;
x2 = (length(signal) - n1) / 2000 * (t - 1) + 1;  % Linear drift signal
noise3 = [x1, x2];  % Combine baseline drift
signal3 = noise3 + signal;  % Add drift to ECG signal

% Plot the noisy signal (with baseline drift)
figure(2);
subplot(3,1,2);
plot(signal3);
title('ECG Signal with Baseline Drift');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the noisy ECG signal
XK2 = fft(signal3, 1800);
magXK2 = abs(XK2);  % Magnitude spectrum
figure(3);
subplot(3,1,2);
k2 = 0:length(magXK2)-1;
stem(k2, magXK2, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('ECG Signal with Baseline Drift Spectrum');

%% 3. FIR High-Pass Filter Design to Remove Baseline Drift

% Define cut-off frequency for the high-pass filter
fc = 0.5;  % Cut-off frequency in Hz
N = 100;  % Filter order

% Normalize cut-off frequency
Wn = fc / (Fs / 2);  % Normalized frequency for FIR filter

% Design the FIR filter using the window method (Hamming window)
b_fir = fir1(N, Wn, 'high');  % FIR high-pass filter coefficients

% Apply the FIR filter to the noisy signal
y_fir = filter(b_fir, 1, signal3);  % Apply FIR high-pass filter

% Plot the frequency response of the FIR high-pass filter
[H_fir, W_fir] = freqz(b_fir, 1, 1024);  % Frequency response of FIR filter
figure(1);
subplot(1,1,1);
plot(W_fir / pi, 20 * log10(abs(H_fir)));  % Plot magnitude response in dB
xlabel('\omega/\pi');
ylabel('Magnitude (dB)');
title('FIR High-Pass Filter Frequency Response');
grid on;

%% 4. Plot Filtered ECG Signal
figure(2);
subplot(3, 1, 3);
plot(y_fir);
title('FIR High-Pass Filtered Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the filtered ECG signal
XK3 = fft(y_fir, 1800);
magXK3 = abs(XK3);  % Magnitude spectrum

figure(3);
subplot(3,1,3);
k3 = 0:length(magXK3)-1;
stem(k3, magXK3, '.');  % Plot the magnitude spectrum of filtered signal
xlabel('k');
ylabel('|X(k)|');
title('FIR High-Pass Filtered Signal Spectrum');

%% 5. Calculate Signal-to-Noise Ratio (SNR)

% Signal Power (Clean ECG signal)
signal_power = rms(signal)^2;

% Noise Power Before Filtering (Noisy signal - Clean signal)
noise_power_before = rms(signal3 - signal)^2;

% SNR Before Filtering
SNR_before = 10 * log10(signal_power / noise_power_before);
fprintf('SNR Before Filtering: %.2f dB\n', SNR_before);

% Noise Power After Filtering (Filtered signal - Clean signal)
noise_power_after = rms(y_fir - signal)^2;

% SNR After Filtering
SNR_after = 10 * log10(signal_power / noise_power_after);
fprintf('SNR After FIR Filtering: %.2f dB\n', SNR_after);
