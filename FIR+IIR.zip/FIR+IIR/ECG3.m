clear, clc;

%% 1. Load ECG Data
load('ECG_database.mat');  % Load ECG data
signal = Data3(1:1800);  % Extract first 1800 samples of ECG signal
Fs = FS;  % Sampling frequency from the data

%% 2. Plot Clean ECG Signal
figure(2);
subplot(3,1,1);
plot(signal);
title('Clean ECG Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the clean ECG signal
XK1 = fft(signal, 1800);
magXK1 = abs(XK1);  % Magnitude spectrum

figure(3);
subplot(3,1,1);
k1 = 0:length(magXK1)-1;
stem(k1, magXK1, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('Clean ECG Signal Spectrum');

%% 3. Add 50Hz Power Line Interference
av = 100;  % Amplitude of noise
f0 = 50;   % Frequency of power line interference
t = 1:length(signal);
noise2 = av * cos(2 * pi * f0 * t / Fs);  % Generate interference signal
signal2 = noise2 + signal;  % Add interference to ECG signal

% Plot the noisy signal
figure(2);
subplot(3,1,2);
plot(signal2);
title('ECG Signal with Interference');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the noisy ECG signal
XK2 = fft(signal2, 1800);
magXK2 = abs(XK2);  % Magnitude spectrum

figure(3);
subplot(3,1,2);
k2 = 0:length(magXK2)-1;
stem(k2, magXK2, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('ECG Signal with Interference Spectrum');

%% 4. IIR Band-Stop Filter Design to Remove 50Hz Noise
wp = [0.18, 0.22];  % Passband edge frequencies (normalized)
ws = [0.192, 0.208];  % Stopband edge frequencies (normalized)
Rp = 1;  % Passband ripple (dB)
Rs = 15;  % Stopband attenuation (dB)

% Calculate the filter order and cutoff frequency
[N, Wn] = buttord(wp, ws, Rp, Rs, 's');  % Calculate filter order
[b, a] = butter(N, Wn, 'stop');  % Design IIR band-stop filter

% Plot the frequency response of the filter
n = 0:0.001:pi;
[H, W] = freqz(b, a, n);
[h, t] = impz(b, a);
y = conv(signal2, h, 'same');  % Apply the band-stop filter using convolution

figure(1);
subplot(1,1,1);
plot(W / pi, 20 * log10(abs(H)));  % Plot the filter frequency response
xlabel('\omega/\pi');
ylabel('Amplitude (dB)');
title('IIR Band-Stop Frequency Response');
grid on;

%% 5. Plot Filtered Signal
figure(2);
subplot(3,1,3);
plot(y);
title('IIR Band-Stop Filtered Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the filtered ECG signal
XK3 = fft(y, 1800);
magXK3 = abs(XK3);  % Magnitude spectrum

figure(3);
subplot(3,1,3);
k3 = 0:length(magXK3)-1;
stem(k3, magXK3, '.');  % Plot the magnitude spectrum of filtered signal
xlabel('k');
ylabel('|X(k)|');
title('IIR Band-Stop Filtered Signal Spectrum');

%% 6. Calculate SNR Before and After Filtering

% Signal Power (Clean ECG signal)
signal_power = rms(signal)^2;

% Noise Power Before Filtering (Noisy signal - Clean signal)
noise_power_before = rms(signal2 - signal)^2;

% SNR before filtering
SNR_before = 10 * log10(signal_power / noise_power_before);
fprintf('SNR before filtering: %.2f dB\n', SNR_before);

% Noise Power After Filtering (Filtered signal - Clean signal)
noise_power_after = rms(y - signal)^2;

% SNR after filtering
SNR_after = 10 * log10(signal_power / noise_power_after);
fprintf('SNR after filtering: %.2f dB\n', SNR_after);

%% 7. Calculate MSE, RMSE, and PRD

% MSE Calculation
mse_noisy = mean((signal2 - signal).^2);  % MSE for noisy signal
mse_filtered = mean((y - signal).^2);    % MSE for filtered signal

% RMSE Calculation
rmse_noisy = sqrt(mse_noisy);  % RMSE for noisy signal
rmse_filtered = sqrt(mse_filtered);  % RMSE for filtered signal

% PRD Calculation
prd_noisy = (norm(signal2 - signal) / norm(signal)) * 100;  % PRD for noisy signal
prd_filtered = (norm(y - signal) / norm(signal)) * 100;     % PRD for filtered signal

% Display MSE, RMSE, and PRD results
fprintf('MSE for noisy signal: %.6f\n', mse_noisy);
fprintf('RMSE for noisy signal: %.6f\n', rmse_noisy);
fprintf('PRD for noisy signal: %.2f%%\n', prd_noisy);

fprintf('MSE for filtered signal: %.6f\n', mse_filtered);
fprintf('RMSE for filtered signal: %.6f\n', rmse_filtered);
fprintf('PRD for filtered signal: %.2f%%\n', prd_filtered);
