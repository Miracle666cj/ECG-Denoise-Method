clear, clc;

%% 1. Load Data
load('ECG_database.mat');  
signal = Data3(1:1800);   % Original ECG signal (first 1800 points)
Fs = FS;                  % Sampling frequency
t = (0:length(signal)-1) / Fs; % Time vector

%% 2. Add Gaussian White Noise
SNR_input = 10;                               % Set the SNR value for adding noise
signal_noisy = awgn(signal, SNR_input, 'measured');  % Add Gaussian noise

% Calculate signal power and noise power for SNR calculation
signal_power = rms(signal)^2;                        % Signal power
noise_power = rms(signal_noisy - signal)^2;          % Noise power
SNR_before = 10 * log10(signal_power / noise_power); % Signal-to-noise ratio (SNR)

fprintf('SNR before filtering: %.2f dB\n', SNR_before);

%% 3. FIR Low-pass Filter Design
fc_fir = 40;                          % Cut-off frequency for FIR filter (Hz)
order_fir = 50;                       % FIR filter order
h_fir = fir1(order_fir, fc_fir / (Fs / 2), 'low');  % Design FIR filter
signal_fir = filtfilt(h_fir, 1, signal_noisy);      % Apply FIR filter

% Calculate SNR after FIR filtering
residual_noise_fir = signal_fir - signal;         % Residual noise after FIR filtering
noise_power_fir = rms(residual_noise_fir)^2;      % Noise power
SNR_fir = 10 * log10(signal_power / noise_power_fir);

fprintf('SNR after FIR filtering: %.2f dB\n', SNR_fir);

%% 4. IIR Low-pass Filter Design
wp = 40 / (Fs / 2);                  % Normalized passband cut-off frequency
ws = 50 / (Fs / 2);                  % Normalized stopband cut-off frequency
Rp = 1; Rs = 40;                     % Passband and stopband ripple (dB)
[N_iir, Wn] = buttord(wp, ws, Rp, Rs);      % Calculate IIR filter order
[b_iir, a_iir] = butter(N_iir, Wn, 'low');  % Design IIR filter
signal_iir = filtfilt(b_iir, a_iir, signal_noisy); % Apply IIR filter

% Calculate SNR after IIR filtering
residual_noise_iir = signal_iir - signal;         % Residual noise after IIR filtering
noise_power_iir = rms(residual_noise_iir)^2;      % Noise power
SNR_iir = 10 * log10(signal_power / noise_power_iir);

fprintf('SNR after IIR filtering: %.2f dB\n', SNR_iir);

%% 5. Calculate MSE and PRD

% FIR Filter
mse_fir = mean((signal_fir - signal).^2);  % MSE for FIR filtered signal
prd_fir = (norm(signal_fir - signal) / norm(signal)) * 100;  % PRD for FIR filtered signal

% IIR Filter
mse_iir = mean((signal_iir - signal).^2);  % MSE for IIR filtered signal
prd_iir = (norm(signal_iir - signal) / norm(signal)) * 100;  % PRD for IIR filtered signal

% Noisy Signal
mse_noisy = mean((signal_noisy - signal).^2);  % MSE for noisy signal
prd_noisy = (norm(signal_noisy - signal) / norm(signal)) * 100;  % PRD for noisy signal

%% 6. Plot Three Separate Figures

% Figure 1: Noisy ECG signal
figure(1);
plot(t, signal_noisy, 'b');
title(['Noisy ECG Signal (SNR = ', num2str(SNR_before, '%.2f'), ' dB)']);
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Figure 2: FIR filtered ECG signal
figure(2);
plot(t, signal_fir, 'g');
title(['ECG Signal After FIR Filtering (SNR = ', num2str(SNR_fir, '%.2f'), ' dB)']);
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Figure 3: IIR filtered ECG signal
figure(3);
plot(t, signal_iir, 'r');
title(['ECG Signal After IIR Filtering (SNR = ', num2str(SNR_iir, '%.2f'), ' dB)']);
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

%% 7. Display Summary Results
fprintf('\n--- Summary of Results ---\n');
fprintf('SNR before filtering: %.2f dB\n', SNR_before);
fprintf('SNR after FIR filtering: %.2f dB\n', SNR_fir);
fprintf('SNR after IIR filtering: %.2f dB\n', SNR_iir);
fprintf('MSE for noisy signal: %.6f\n', mse_noisy);
fprintf('PRD for noisy signal: %.2f%%\n', prd_noisy);
fprintf('MSE for FIR filtered signal: %.6f\n', mse_fir);
fprintf('PRD for FIR filtered signal: %.2f%%\n', prd_fir);
fprintf('MSE for IIR filtered signal: %.6f\n', mse_iir);
fprintf('PRD for IIR filtered signal: %.2f%%\n', prd_iir);
