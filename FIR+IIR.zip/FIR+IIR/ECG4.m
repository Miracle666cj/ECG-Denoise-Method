clear, clc;

%% 1. Load ECG Data
load('ECG_database.mat');  % Load ECG data
signal = Data3(1:1800);  % Extract first 1800 samples of ECG signal
Fs = FS;  % Sampling frequency from the data

%% 2. Plot Clean ECG Signal
figure(2);
subplot(3,1,1);
plot(signal);
title('Clean ECG Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the clean ECG signal
XK1 = fft(signal, 1800);
magXK1 = abs(XK1);  % Magnitude spectrum
figure(3);
subplot(3,1,1);
k1 = 0:length(magXK1)-1;
stem(k1, magXK1, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('Clean ECG Signal Spectrum');

%% 3. Add Baseline Drift to the Signal
n1 = length(signal) / 3;
x1 = zeros(1, n1);
t = 1:length(signal) - n1;
x2 = (length(signal) - n1) / 2000 * (t - 1) + 1;  % Linear drift signal
noise3 = [x1, x2];  % Combine baseline drift
signal3 = noise3 + signal;  % Add drift to ECG signal

% Plot the noisy signal (with baseline drift)
figure(2);
subplot(3,1,2);
plot(signal3);
title('ECG Signal with Baseline Drift');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the noisy ECG signal
XK2 = fft(signal3, 1800);
magXK2 = abs(XK2);  % Magnitude spectrum
figure(3);
subplot(3,1,2);
k2 = 0:length(magXK2)-1;
stem(k2, magXK2, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('ECG Signal with Baseline Drift Spectrum');

%% 4. IIR High-Pass Filter Design to Remove Baseline Drift

wp = 0.0028 * pi;  % Passband frequency (normalized)
ws = 0.0012 * pi;  % Stopband frequency (normalized)
Rp = 1;  % Passband ripple (dB)
Rs = 15;  % Stopband attenuation (dB)

% Convert to analog frequencies
wp1 = 2 * Fs * tan(wp / 2);
ws1 = 2 * Fs * tan(ws / 2);

% Calculate filter order and cutoff frequency
[N, Wn] = buttord(wp1, ws1, Rp, Rs, 's');
[b, a] = butter(N, Wn, 'high', 's');  % Analog high-pass filter
[Z, P, K] = buttap(N);  % Prototype filter for high-pass
[bz, az] = bilinear(b, a, Fs);  % Convert to digital filter using bilinear transform

% Compute frequency response of the filter
[H, W] = freqz(bz, az);

% Apply the high-pass filter
y = filter(bz, az, signal3);  % Apply high-pass filter to the signal with baseline drift

% Plot the frequency response of the high-pass filter
figure(1);
subplot(1, 1, 1);
plot(W / pi, 20 * log10(abs(H)));  % Plot magnitude response in dB
xlabel('\omega/\pi');
ylabel('Magnitude (dB)');
title('IIR High-Pass Frequency Response');
grid on;

%% 5. Plot Filtered ECG Signal
figure(2);
subplot(3,1,3);
plot(y);
title('IIR High-Pass Filtered Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the filtered ECG signal
XK3 = fft(y, 1800);
magXK3 = abs(XK3);  % Magnitude spectrum

figure(3);
subplot(3,1,3);
k3 = 0:length(magXK3)-1;
stem(k3, magXK3, '.');  % Plot the magnitude spectrum of filtered signal
xlabel('k');
ylabel('|X(k)|');
title('IIR High-Pass Filtered Signal Spectrum');

%% 6. Calculate Signal-to-Noise Ratio (SNR)

% Signal Power (Clean ECG signal)
signal_power = rms(signal)^2;

% Noise Power Before Filtering (Noisy signal - Clean signal)
noise_power_before = rms(signal3 - signal)^2;

% SNR Before Filtering
SNR_before = 10 * log10(signal_power / noise_power_before);
fprintf('SNR Before Filtering: %.2f dB\n', SNR_before);

% Noise Power After Filtering (Filtered signal - Clean signal)
noise_power_after = rms(y - signal)^2;

% SNR After Filtering
SNR_after = 10 * log10(signal_power / noise_power_after);
fprintf('SNR After Filtering: %.2f dB\n', SNR_after);

%% 7. Calculate MSE, RMSE, and PRD

% MSE Calculation
mse_noisy = mean((signal3 - signal).^2);  % MSE for noisy signal
mse_filtered = mean((y - signal).^2);    % MSE for filtered signal

% RMSE Calculation
rmse_noisy = sqrt(mse_noisy);  % RMSE for noisy signal
rmse_filtered = sqrt(mse_filtered);  % RMSE for filtered signal

% PRD Calculation
prd_noisy = (norm(signal3 - signal) / norm(signal)) * 100;  % PRD for noisy signal
prd_filtered = (norm(y - signal) / norm(signal)) * 100;     % PRD for filtered signal

% Display MSE, RMSE, and PRD results
fprintf('MSE for noisy signal: %.6f\n', mse_noisy);
fprintf('RMSE for noisy signal: %.6f\n', rmse_noisy);
fprintf('PRD for noisy signal: %.2f%%\n', prd_noisy);

fprintf('MSE for filtered signal: %.6f\n', mse_filtered);
fprintf('RMSE for filtered signal: %.6f\n', rmse_filtered);
fprintf('PRD for filtered signal: %.2f%%\n', prd_filtered);
