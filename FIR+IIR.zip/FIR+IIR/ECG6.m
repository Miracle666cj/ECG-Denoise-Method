clear, clc;

%% 1. Load ECG Data
load('ECG_database.mat');  % Load ECG data
signal = Data3(1:1800);  % Extract first 1800 samples of ECG signal
Fs = FS;  % Sampling frequency from the data

%% 2. Plot Clean ECG Signal
figure(2);
subplot(3,1,1);
plot(signal);
title('Clean ECG Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the clean ECG signal
XK1 = fft(signal, 1800);
magXK1 = abs(XK1);  % Magnitude spectrum

figure(3);
subplot(3,1,1);
k1 = 0:length(magXK1)-1;
stem(k1, magXK1, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('Clean ECG Signal Spectrum');

%% 3. Add 50Hz Power Line Interference
av = 100;  % Amplitude of noise
f0 = 50;   % Frequency of power line interference
t = 1:length(signal);
noise2 = av * cos(2 * pi * f0 * t / Fs);  % Generate interference signal
signal2 = noise2 + signal;  % Add interference to ECG signal

% Plot the noisy signal
figure(2);
subplot(3,1,2);
plot(signal2);
title('ECG Signal with Interference');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the noisy ECG signal
XK2 = fft(signal2, 1800);
magXK2 = abs(XK2);  % Magnitude spectrum

figure(3);
subplot(3,1,2);
k2 = 0:length(magXK2)-1;
stem(k2, magXK2, '.');  % Plot the magnitude spectrum
xlabel('k');
ylabel('|X(k)|');
title('ECG Signal with Interference Spectrum');

%% 4. FIR Band-Stop Filter Design to Remove 50Hz Noise

% Define the stopband edges and the passband edges in normalized frequency
wp = [0.18, 0.22];  % Passband edge frequencies (normalized)
ws = [0.192, 0.208];  % Stopband edge frequencies (normalized)

% Filter order (larger order gives better stopband attenuation)
N = 200;  % Filter order (you can experiment with this)

% Design the FIR band-stop filter using the window method
fstop = [0.19 0.21];  % Stopband frequencies in Hz
fpass = [0.18 0.22];  % Passband frequencies in Hz
Wn = fstop / (Fs / 2);  % Normalize frequencies

% Design the filter using fir1 function
b_fir = fir1(N, Wn, 'stop');  % FIR band-stop filter coefficients

% Apply the FIR filter to the noisy signal
y_fir = filter(b_fir, 1, signal2);  % Apply FIR band-stop filter

% Plot the frequency response of the FIR filter
[H_fir, W_fir] = freqz(b_fir, 1, 1024);  % Frequency response of FIR filter
figure(1);
subplot(1,1,1);
plot(W_fir / pi, 20 * log10(abs(H_fir)));  % Plot magnitude response in dB
xlabel('\omega/\pi');
ylabel('Magnitude (dB)');
title('FIR Band-Stop Frequency Response');
grid on;

%% 5. Plot Filtered Signal
figure(2);
subplot(3, 1, 3);
plot(y_fir);
title('FIR Band-Stop Filtered Signal');
xlabel('Sample Points'); ylabel('Amplitude (dB)');
grid on;

% Perform FFT on the filtered ECG signal
XK3 = fft(y_fir, 1800);
magXK3 = abs(XK3);  % Magnitude spectrum

figure(3);
subplot(3,1,3);
k3 = 0:length(magXK3)-1;
stem(k3, magXK3, '.');  % Plot the magnitude spectrum of filtered signal
xlabel('k');
ylabel('|X(k)|');
title('FIR Band-Stop Filtered Signal Spectrum');

%% 6. Calculate SNR Before and After Filtering

% Signal Power (Clean ECG signal)
signal_power = rms(signal)^2;

% Noise Power Before Filtering (Noisy signal - Clean signal)
noise_power_before = rms(signal2 - signal)^2;

% SNR before filtering
SNR_before = 10 * log10(signal_power / noise_power_before);
fprintf('SNR before filtering: %.2f dB\n', SNR_before);

% Noise Power After Filtering (Filtered signal - Clean signal)
noise_power_after = rms(y_fir - signal)^2;

% SNR after filtering
SNR_after = 10 * log10(signal_power / noise_power_after);
fprintf('SNR after FIR filtering: %.2f dB\n', SNR_after);
