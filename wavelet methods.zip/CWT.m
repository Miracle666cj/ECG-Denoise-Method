set(0, 'DefaultAxesFontName', 'Times New Roman'); 
set(0, 'DefaultAxesFontSize', 14); 
set(0, 'DefaultTextFontName', 'Times New Roman'); 
set(0, 'DefaultTextFontSize', 14);

% Load ECG data file
load('ECG_database.mat'); 
x = Data3(1, :); % Extract the first lead signal as the analysis target
fs = FS; % Sampling frequency

% Parameters for noise addition
snr_db = 10; % Desired SNR in dB for the added noise

% Calculate the power of the original signal
signal_power = sum(x.^2) / length(x);

% Calculate the noise power required to achieve the desired SNR
noise_power = signal_power / (10^(snr_db / 10));

% Generate Gaussian noise
noise = sqrt(noise_power) * randn(size(x));

% Add noise to the original signal
x_noisy = x + noise; 

% Perform Continuous Wavelet Transform (CWT)
[wcoefs, freq] = cwt(x_noisy, 'amor', fs); % Use 'amor' (Morlet wavelet) for CWT

% Remove unwanted frequency components
% Define frequency range of interest (e.g., 0.5 Hz to 40 Hz for ECG signal)
freq_range = freq >= 0.5 & freq <= 40; 
wcoefs_filtered = zeros(size(wcoefs)); % Initialize filtered coefficients
wcoefs_filtered(freq_range, :) = wcoefs(freq_range, :); % Retain only the coefficients in this range

% Reconstruct the signal from filtered coefficients
x_denoised = icwt(wcoefs_filtered, 'amor'); % Perform inverse CWT using 'amor'

% Calculate SNR
noise_power_before = sum((x - x_noisy).^2) / length(x); 
noise_power_after = sum((x - x_denoised).^2) / length(x); 
snr_before = 10 * log10(signal_power / noise_power_before); 
snr_after = 10 * log10(signal_power / noise_power_after); 

% Calculate MSE and RMSE
mse_noisy = mean((x - x_noisy).^2); % MSE for noisy signal
rmse_noisy = sqrt(mse_noisy); % RMSE for noisy signal

mse_denoised = mean((x - x_denoised).^2); % MSE for denoised signal
rmse_denoised = sqrt(mse_denoised); % RMSE for denoised signal

% Calculate PRD
prd_noisy = (norm(x - x_noisy) / norm(x)) * 100; % PRD for noisy signal
prd_denoised = (norm(x - x_denoised) / norm(x)) * 100; % PRD for denoised signal

% Set time axis
t1 = (0:length(x)-1) / fs;

% Plot overlay of Noisy and Denoised ECG Signals
figure;
plot(t1, x_noisy, 'g', 'LineWidth', 1.5, 'DisplayName', sprintf('Noisy Signal (SNR = %.2f dB)', snr_before)); hold on;
plot(t1, x_denoised, 'r', 'LineWidth', 1.5, 'DisplayName', sprintf('Denoised Signal (SNR = %.2f dB)', snr_after));
hold off;

title('Comparison of Noisy and Denoised ECG Signals Using CWT');
xlabel('Time (seconds)');
ylabel('Amplitude');
legend('show', 'Location', 'best');
grid on;

% Display SNR, MSE, RMSE, and PRD results in the console
fprintf('SNR before denoising: %.2f dB\n', snr_before);
fprintf('SNR after denoising: %.2f dB\n', snr_after);
fprintf('MSE for noisy signal: %.6f\n', mse_noisy);
fprintf('RMSE for noisy signal: %.6f\n', rmse_noisy);
fprintf('MSE for denoised signal: %.6f\n', mse_denoised);
fprintf('RMSE for denoised signal: %.6f\n', rmse_denoised);
fprintf('PRD for noisy signal: %.2f%%\n', prd_noisy);
fprintf('PRD for denoised signal: %.2f%%\n', prd_denoised);
