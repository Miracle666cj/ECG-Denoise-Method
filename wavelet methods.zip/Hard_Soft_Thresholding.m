% Set global figure properties
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultAxesFontSize', 14);
set(0, 'DefaultTextFontName', 'Times New Roman');
set(0, 'DefaultTextFontSize', 14);

% Load ECG data file
load('ECG_database.mat'); 
x = Data3(1, :); % Extract the first lead signal as the analysis target
fs = FS; % Sampling frequency

% Parameters for noise addition
snr_db = 10; % Desired SNR in dB for the added noise

% Calculate the power of the original signal
signal_power = sum(x.^2) / length(x);

% Calculate the noise power required to achieve the desired SNR
noise_power = signal_power / (10^(snr_db / 10));

% Generate Gaussian noise
noise = sqrt(noise_power) * randn(size(x));

% Add noise to the original signal
x_noisy = x + noise; 

% Perform Continuous Wavelet Transform (CWT)
[wcoefs, freq] = cwt(x_noisy, 'amor', fs); % Use 'amor' (Morlet wavelet) for CWT

% 1. Hard Thresholding (SureShrink)
threshold_hard = median(abs(wcoefs(:))) / 0.6745 * sqrt(2 * log(length(x_noisy))); % SureShrink threshold
wcoefs_hard = wcoefs;
wcoefs_hard(abs(wcoefs_hard) < threshold_hard) = 0; % Hard thresholding
x_denoised_hard = icwt(wcoefs_hard, 'amor'); % Reconstruct the signal

% 2. Soft Thresholding (BayesShrink)
noise_var = (median(abs(wcoefs(:))) / 0.6745)^2; % Estimate noise variance
signal_var = var(wcoefs(:)); % Estimate signal variance
threshold_soft = noise_var ./ (signal_var + eps); % BayesShrink threshold
wcoefs_soft = sign(wcoefs) .* max(abs(wcoefs) - threshold_soft, 0); % Soft thresholding
x_denoised_soft = icwt(wcoefs_soft, 'amor'); % Reconstruct the signal

% Calculate SNRs
noise_power_after_hard = sum((x - x_denoised_hard).^2) / length(x); 
snr_after_hard = 10 * log10(signal_power / noise_power_after_hard); 

noise_power_after_soft = sum((x - x_denoised_soft).^2) / length(x); 
snr_after_soft = 10 * log10(signal_power / noise_power_after_soft); 

% Define time vector
t1 = (0:length(x)-1) / fs;

% Plot original signal
figure;
plot(t1, x, 'b', 'LineWidth', 1.5);
title('Original ECG Signal');
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;

% Plot noisy signal
figure;
plot(t1, x_noisy, 'g', 'LineWidth', 1.5);
title('Noisy ECG Signal');
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;

% Plot Hard Thresholding Result
figure;
plot(t1, x_denoised_hard, 'r', 'LineWidth', 1.5);
title(sprintf('Hard Thresholding Result (SNR = %.2f dB)', snr_after_hard));
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;

% Plot Soft Thresholding Result
figure;
plot(t1, x_denoised_soft, 'm', 'LineWidth', 1.5);
title(sprintf('Soft Thresholding Result (SNR = %.2f dB)', snr_after_soft));
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;

% Display Results
fprintf('SNR after Hard Thresholding (SureShrink): %.2f dB\n', snr_after_hard);
fprintf('SNR after Soft Thresholding (BayesShrink): %.2f dB\n', snr_after_soft);

% Calculate MSE and PRD for Hard Thresholding
mse_hard = sum((x - x_denoised_hard).^2) / length(x);  % MSE for Hard Thresholding
prd_hard = sqrt(sum((x - x_denoised_hard).^2) / length(x)) / (max(x) - min(x)) * 100;  % PRD for Hard Thresholding

% Calculate MSE and PRD for Soft Thresholding
mse_soft = sum((x - x_denoised_soft).^2) / length(x);  % MSE for Soft Thresholding
prd_soft = sqrt(sum((x - x_denoised_soft).^2) / length(x)) / (max(x) - min(x)) * 100;  % PRD for Soft Thresholding

% Display MSE and PRD results
fprintf('MSE after Hard Thresholding (SureShrink): %.4f\n', mse_hard);
fprintf('PRD after Hard Thresholding (SureShrink): %.2f%%\n', prd_hard);
fprintf('MSE after Soft Thresholding (BayesShrink): %.4f\n', mse_soft);
fprintf('PRD after Soft Thresholding (BayesShrink): %.2f%%\n', prd_soft);
