set(0, 'DefaultAxesFontName', 'Times New Roman'); 
set(0, 'DefaultAxesFontSize', 14); 
set(0, 'DefaultTextFontName', 'Times New Roman'); 
set(0, 'DefaultTextFontSize', 14);

% Load ECG data file
load('ECG_database.mat'); 
x = Data3(1, :); 

% Parameters for noise addition
snr_db = 10; 

% Calculate the power of the original signal
signal_power = sum(x.^2) / length(x);

% Calculate the noise power required to achieve the desired SNR
noise_power = signal_power / (10^(snr_db / 10));

% Generate Gaussian noise
noise = sqrt(noise_power) * randn(size(x));

% Add noise to the original signal
x_noisy = x + noise; 

% Set wavelet denoising parameters
wavename = 'db5'; 
level = 4; 

% Perform wavelet decomposition
[c, l] = wavedec(x_noisy, level, wavename);

% Set threshold denoising parameters
alpha = 1.5; 
sorh = 's'; 

% Perform threshold denoising using Birge-Massart strategy
[thr, nkeep] = wdcbm(c, l, alpha); 
[xc, cxc, lxc, perf0, perfl2] = wdencmp('lvd', c, l, wavename, level, thr, sorh);

% Calculate SNR
noise_power_before = sum((x - x_noisy).^2) / length(x); 
noise_power_after = sum((x - xc).^2) / length(x); 
snr_before = 10 * log10(signal_power / noise_power_before); 
snr_after = 10 * log10(signal_power / noise_power_after); 

% Calculate MSE and RMSE
mse_noisy = mean((x - x_noisy).^2); % MSE for noisy signal
rmse_noisy = sqrt(mse_noisy); % RMSE for noisy signal

mse_denoised = mean((x - xc).^2); % MSE for denoised signal
rmse_denoised = sqrt(mse_denoised); % RMSE for denoised signal

% Calculate PRD
prd_noisy = (norm(x - x_noisy) / norm(x)) * 100; % PRD for noisy signal
prd_denoised = (norm(x - xc) / norm(x)) * 100; % PRD for denoised signal

% Set time axis
t1 = 0:0.004:(length(x) - 1) * 0.004;

% Plot overlay of Noisy and Denoised ECG Signals
figure;
plot(t1, x_noisy, 'g', 'LineWidth', 1.5, 'DisplayName', sprintf('Noisy Signal (SNR = %.2f dB)', snr_before)); hold on;
plot(t1, xc, 'r', 'LineWidth', 1.5, 'DisplayName', sprintf('Denoised Signal (SNR = %.2f dB)', snr_after));
hold off;

title('Comparison of Noisy and Denoised ECG Signals(DWT)');
xlabel('Time (seconds)');
ylabel('Amplitude');
legend('show', 'Location', 'best');
grid on;

% Display SNR, MSE, RMSE, and PRD results in the console
fprintf('SNR before denoising: %.2f dB\n', snr_before);
fprintf('SNR after denoising: %.2f dB\n', snr_after);
fprintf('MSE for noisy signal: %.6f\n', mse_noisy);
fprintf('RMSE for noisy signal: %.6f\n', rmse_noisy);
fprintf('MSE for denoised signal: %.6f\n', mse_denoised);
fprintf('RMSE for denoised signal: %.6f\n', rmse_denoised);
fprintf('PRD for noisy signal: %.2f%%\n', prd_noisy);
fprintf('PRD for denoised signal: %.2f%%\n', prd_denoised);
