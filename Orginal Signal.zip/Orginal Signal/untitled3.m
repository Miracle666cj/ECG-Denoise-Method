set(0, 'DefaultAxesFontName', 'Times New Roman'); % Set axes font
set(0, 'DefaultAxesFontSize', 14); % Set axes font size
set(0, 'DefaultTextFontName', 'Times New Roman'); % Set text font
set(0, 'DefaultTextFontSize', 14); % Set text font size

% Load data
clear all;
load("ECG_database.mat");

% Select variables
ECG_signal = Data3;   % Select ECG raw data
fs = FS;              % Sampling frequency
T = 1 / fs;           % Sampling period
t = (0:length(ECG_signal)-1) * T;  % Time vector

% Plot original ECG data
figure;
plot(t, ECG_signal, 'LineWidth', 1.5);
title('Original ECG Signal');
xlabel('Time (s)');
ylabel('Amplitude (mV)');
grid on;
